from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from vegbag.cart.forms import DiscountCodeForm
from decimal import Decimal

@login_required
def view_shopping_cart(request):
    # Get the current user's cart
    user_cart = request.user.cart

    # Get the cart items associated with the user's cart
    cart_items = user_cart.cart_item.all()

    # Calculate total price for each item and check for discounts
    for item in cart_items:
        if item.product.is_discount:
            item.discounted_price = item.product.price - (item.product.price * item.product.discount / 100)
        else:
            item.discounted_price = item.product.price

        item.total_price = item.discounted_price * item.quantity

    # Calculate total price of all items in the cart
    subtotal = sum(item.total_price for item in cart_items)
    total = subtotal  # Assuming there are no additional fees or discounts

    # Initialize discount and error_message
    discount = 0
    error_message = None

    if request.method == 'POST':
        form = DiscountCodeForm(request.POST)
        if form.is_valid():
            coupon_code = form.cleaned_data['coupon_code']
            if coupon_code == 'VG2':
                discount = subtotal * Decimal('0.20')
                total = subtotal - discount
            else:
                # Invalid coupon code
                error_message = "Invalid coupon code"
        else:
            # Form is invalid
            error_message = "Invalid coupon code"
    else:
        form = DiscountCodeForm()

    return render(request, 'shopping-cart.html',
                  {'cart_items': cart_items, 'subtotal': subtotal, 'total': total, 'form': form, 'discount': discount,
                   'error_message': error_message})
